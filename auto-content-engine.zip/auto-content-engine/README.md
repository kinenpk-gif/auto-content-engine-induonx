# AutoContent Engine

Plataforma modular para descoberta de temas, geração de conteúdo, fila, publicação por adapters oficiais, analytics, aprendizado estatístico e monetização.

## Estado do projeto

- **Modo DEMO funcional sem APIs pagas**: banco, descoberta, scoring, geração textual, fila, publicação mock, métricas, aprendizado e dashboard.
- **Integrações externas**: adapters preparados e protegidos por variáveis de ambiente. Nenhuma integração é declarada como ativa sem credenciais/configuração.
- **Receita**: só é apresentada como real quando `is_demo=false` e os dados vierem de uma integração/fonte real.

> **Dados demonstrativos — não representam receita real.**

## Estrutura

```text
auto-content-engine/
├── backend/
│   ├── app/
│   │   ├── api/                 # rotas FastAPI
│   │   ├── core/                # configuração
│   │   ├── models/              # SQLAlchemy
│   │   ├── schemas/             # Pydantic
│   │   ├── services/            # regras de negócio
│   │   ├── providers/            # IA/texto/imagem/vídeo
│   │   ├── adapters/             # YouTube/Instagram/TikTok/Mock
│   │   ├── algorithms/           # scoring e aprendizado
│   │   ├── database/             # engine/sessões
│   │   ├── workers/              # scheduler
│   │   └── main.py
│   ├── alembic/                  # migrations
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/                     # React + TypeScript + Tailwind + Recharts
├── scripts/seed_demo.py
├── config.yaml
├── .env.example
├── docker-compose.yml
└── tests/
```

## Instalação local

### 1. Python

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r backend/requirements.txt
```

### 2. Configuração

```bash
cp .env.example .env
```

Para DEMO, não é necessário preencher nenhuma chave. O banco padrão local é SQLite se `DATABASE_URL` não for definido.

### 3. Banco e dados DEMO

```bash
python scripts/seed_demo.py
```

### 4. Backend

```bash
cd backend
uvicorn app.main:app --reload --port 8000
```

API: `http://localhost:8000/api`
Docs: `http://localhost:8000/docs`

### 5. Frontend

Em outro terminal:

```bash
cd frontend
npm install
npm run dev
```

Frontend: `http://localhost:5173`

## Docker

```bash
docker compose up --build
```

O Docker usa PostgreSQL 16, FastAPI e Vite.

## Variáveis de ambiente

| Variável | Uso |
|---|---|
| `DATABASE_URL` | PostgreSQL/SQLite |
| `IA_PROVIDER` | `demo` ou provider configurado |
| `IA_API_KEY` | chave do provider de IA |
| `IA_MODEL` | modelo escolhido |
| `YOUTUBE_ACCESS_TOKEN` | credencial OAuth do YouTube |
| `INSTAGRAM_ACCESS_TOKEN` | token da Meta/Instagram |
| `INSTAGRAM_BUSINESS_ACCOUNT_ID` | conta profissional |
| `TIKTOK_ACCESS_TOKEN` | token do Content Posting API |
| `SCHEDULER_ENABLED` | liga/desliga APScheduler |
| `CORS_ORIGINS` | origens permitidas |

## Configuração funcional

`config.yaml` controla nicho, idioma, frequência, plataformas, quantidade diária, DEMO e horários.

Scheduler padrão:

- 08:00 pesquisa de temas
- 09:00 geração de roteiros/posts
- 10:00 geração de conteúdo adicional quando providers estiverem configurados
- 11:00 processamento de publicação agendada

O scheduler só roda se `SCHEDULER_ENABLED=true` e o processo FastAPI estiver ativo.

## APIs externas

### YouTube
Adapter reservado para YouTube Data API + OAuth. É necessário criar credenciais no Google Cloud, autorizar o canal e fornecer token válido. O projeto não finge upload real sem credencial.

### Instagram
Usa arquitetura para Instagram Graph API/Meta. É necessário conta profissional, app Meta, permissões e token válidos. Publicação de mídia depende de URL/container de mídia e permissões correspondentes.

### TikTok
Usa arquitetura para TikTok Content Posting API. É necessário app aprovado, OAuth e permissões de publicação.

### IA
O provider é substituível. Sem credenciais, o sistema usa `TextProvider` DEMO determinístico. Para um provider real, configure `IA_PROVIDER`, `IA_API_KEY`, `IA_MODEL` e a implementação correspondente.

## Testes

```bash
pytest -q
```

Os testes cobrem scoring, providers, criação de posts, adapters, métricas, monetização, banco e rotas principais.

## Segurança

- nenhum segredo hardcoded;
- `.env` ignorado pelo Git;
- tokens somente por ambiente;
- adapters falham explicitamente quando não configurados;
- sem scraping proibido, CAPTCHA bypass, spam ou criação massiva de contas.

## Próximos passos para produção

1. Implementar OAuth persistente por plataforma com refresh tokens armazenados em secret manager.
2. Trocar scheduler embutido por Celery/Redis se houver múltiplos workers.
3. Implementar providers de imagem/vídeo com contratos reais.
4. Adicionar autenticação de usuários e RBAC.
5. Criar armazenamento S3-compatible para mídia.
6. Criar observabilidade, rate limiting e auditoria.
7. Integrar APIs de analytics oficiais e separar métricas DEMO/produção.
8. Adicionar migrations incrementais Alembic conforme o schema evoluir.

## Modo AUTONOMOUS — operação real

O projeto agora possui um ciclo autônomo em `POST /api/autonomous/run` e um job APScheduler chamado `autonomous`.

Fluxo:

1. Descobre temas por fontes configuradas.
2. Quando `YOUTUBE_API_KEY` existe, consulta a API oficial do YouTube; sem ela, mantém somente fontes marcadas como DEMO.
3. Seleciona os temas novos de maior score.
4. Gera roteiro e metadados.
5. Gera um vídeo vertical MP4 original localmente com FFmpeg + eSpeak em modo DEMO.
6. Agenda o mesmo master para YouTube/TikTok/Instagram, sem copiar vídeos de terceiros.
7. Publica via adapter oficial quando as credenciais estiverem configuradas; caso contrário usa Mock somente quando `demo_mode=true`.
8. Coleta métricas e alimenta o mecanismo de aprendizado.

### Começar hoje

```bash
cp .env.example .env
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
pip install -r backend/requirements.txt
python scripts/seed_demo.py
uvicorn app.main:app --app-dir backend --reload
```

Em outro terminal:

```bash
curl -X POST http://127.0.0.1:8000/api/autonomous/run
```

Depois abra o frontend:

```bash
cd frontend
npm install
npm run dev
```

### Para sair do DEMO

1. Configure `DATABASE_URL` apontando para PostgreSQL.
2. Configure um provider de IA compatível com a interface do projeto.
3. Configure `YOUTUBE_API_KEY` para descoberta de temas pelo YouTube Data API.
4. Configure OAuth do YouTube e `YOUTUBE_ACCESS_TOKEN` para publicação real.
5. Configure os adapters Meta/TikTok com os tokens e IDs exigidos pelas APIs oficiais.
6. Defina `demo_mode: false` somente depois de validar cada integração.
7. Mantenha `require_original_content`, `reject_unverified_media` e `human_review_on_uncertain_rights` ativados.

### Monetização orientada por plataforma

O sistema não fixa uma duração universal. A duração é uma variável estratégica e deve ser recalculada conforme plataforma, objetivo e políticas vigentes. Por exemplo, o TikTok Creator Rewards exige vídeos originais e de alta qualidade com mais de um minuto para os vídeos qualificados pelo programa. O YouTube também possui requisitos específicos para receita de Shorts e políticas de originalidade. O engine deve tratar esses requisitos como regras configuráveis, não como garantias de receita.

A receita registrada pelo sistema deve continuar sendo real somente quando vier de uma integração real. Métricas e receitas DEMO permanecem identificadas como demonstrativas.
