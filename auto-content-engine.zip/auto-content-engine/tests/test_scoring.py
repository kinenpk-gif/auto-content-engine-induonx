from app.algorithms.scoring import topic_score, performance_score

def test_topic_score_weighted():
    assert topic_score(100,100,100,100,100)==100
    assert topic_score(0,0,0,0,0)==0

def test_performance_score_zero_views():
    assert performance_score(0,1,1,1,1)==0
