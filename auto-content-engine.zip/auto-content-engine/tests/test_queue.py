from datetime import datetime, timezone, timedelta
from app.models import Post
from app.services.publishing_service import publish_due

def test_queue_publish_due(db):
    p=Post(platform='youtube',title='q',status='SCHEDULED',scheduled_at=datetime.now(timezone.utc)-timedelta(minutes=1))
    db.add(p);db.commit();db.refresh(p)
    publish_due(db,demo=True)
    assert p.status=='PUBLISHED' and p.external_id.startswith('demo-youtube-')
