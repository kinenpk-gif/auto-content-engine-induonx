from app.adapters.platforms import MockPlatformAdapter

def test_mock_adapter():
    r=MockPlatformAdapter('youtube').publish(type('P',(),{'id':1})())
    assert r['external_id']=='demo-youtube-1' and r['demo'] is True
