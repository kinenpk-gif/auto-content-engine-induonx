from pathlib import Path
from app.media.video_engine import VideoEngine

def test_real_demo_video(tmp_path):
    r=VideoEngine(tmp_path).render('Teste industrial','Esta é uma demonstração de conteúdo original.',15,'test.mp4')
    p=Path(r['path'])
    assert p.exists() and p.stat().st_size > 10000
