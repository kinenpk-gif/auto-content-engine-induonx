from app.models import Topic
from app.services.content_service import create_post

def test_create_post(db):
    t=Topic(title='Tema demo',category='logística',keywords=['logística'],source='DEMO',relevance=80,interest_potential=80,novelty=80,production_ease=80,monetization_potential=80,score=80)
    db.add(t);db.commit();db.refresh(t)
    p=create_post(db,t,'youtube')
    assert p.id and p.status=='DRAFT' and 'Tema demo' in p.title
