from app.models import Revenue

def test_demo_revenue(db):
    r=Revenue(platform='youtube',source='DEMO',amount=10,currency='BRL',is_demo=True)
    db.add(r);db.commit()
    assert db.query(Revenue).count()==1 and r.is_demo is True
