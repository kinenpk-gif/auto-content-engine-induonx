from app.models import Topic
from app.services.content_service import create_post
from app.services.analytics_service import record_metric
from app.schemas import MetricCreate

def test_metrics(db):
    t=Topic(title='Analytics',category='IA',keywords=['ia'],score=80)
    db.add(t);db.commit();db.refresh(t)
    p=create_post(db,t,'text')
    m=record_metric(db,MetricCreate(content_id=p.id,views=1000,likes=100,comments=10,shares=5,followers_gained=8,ctr=.03))
    assert m.engagement_rate>0 and m.performance_score>0
