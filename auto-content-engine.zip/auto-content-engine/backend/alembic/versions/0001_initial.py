"""initial schema"""
from alembic import op
from app.database.session import Base
from app.models import all_models  # noqa

def upgrade():
    Base.metadata.create_all(bind=op.get_bind())

def downgrade():
    Base.metadata.drop_all(bind=op.get_bind())
