from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import get_settings
from app.database.session import init_db
from app.api.routes import router
from app.workers.scheduler import start_scheduler

settings=get_settings()
app=FastAPI(title=settings.app_name, version='1.0.0')
app.add_middleware(CORSMiddleware,allow_origins=settings.cors_list,allow_credentials=True,allow_methods=['*'],allow_headers=['*'])
app.include_router(router,prefix='/api')

@app.on_event('startup')
def startup():
    init_db(); start_scheduler()
