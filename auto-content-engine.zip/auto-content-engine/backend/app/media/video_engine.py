import subprocess
from pathlib import Path

class VideoEngine:
    """Creates original vertical videos locally. DEMO uses ffmpeg + eSpeak, no paid media API."""
    def __init__(self, output_dir='generated'):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def render(self, title: str, script: str, duration: int = 45, filename: str | None = None):
        duration = max(15, min(int(duration), 180))
        filename = filename or 'content.mp4'
        out = self.output_dir / filename
        stem = out.with_suffix('')
        audio = stem.with_suffix('.wav')
        safe_title = ' '.join(title.split()).replace(':', ' - ').replace("'", "\\'")[:110]
        safe_script = ' '.join(script.split()).replace(':', ' - ').replace("'", "\\'")[:850]
        # Local TTS; it is intentionally generic DEMO narration and can be replaced by a licensed TTS provider.
        subprocess.run(['espeak','-v','pt-br','-s','155','-w',str(audio),safe_script], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        vf = (
            "scale=1080:1920,"
            "drawbox=x=50:y=350:w=980:h=330:color=black@0.55:t=fill,"
            f"drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf:text='{safe_title}':fontcolor=white:fontsize=64:x=(w-text_w)/2:y=470:"
            "box=0,"
            "drawbox=x=50:y=820:w=980:h=620:color=black@0.62:t=fill,"
            f"drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:text='{safe_script}':fontcolor=white:fontsize=38:x=90:y=900:line_spacing=18:"
            "box=0"
        )
        cmd = ['ffmpeg','-y','-f','lavfi','-i','color=c=0x17324d:s=1080x1920:r=30','-i',str(audio),'-t',str(duration),'-vf',vf,'-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest','-movflags','+faststart',str(out)]
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        audio.unlink(missing_ok=True)
        return {'path': str(out), 'demo': True, 'duration': duration}
