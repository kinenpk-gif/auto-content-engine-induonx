from sqlalchemy.orm import Session
from app.models import Revenue

def record_revenue(db: Session, *, platform: str, source: str, amount: float, currency: str='BRL', content_id: int|None=None, is_demo: bool=False):
    r=Revenue(platform=platform,source=source,amount=amount,currency=currency,content_id=content_id,is_demo=is_demo)
    db.add(r); db.commit(); db.refresh(r); return r
