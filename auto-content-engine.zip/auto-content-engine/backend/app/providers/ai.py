import httpx
from app.core.config import get_settings
from .content import TextProvider, GeneratedContent

class ConfigurableLLMProvider:
    """Provider genérico. Espera uma API compatível com JSON simples via IA_BASE_URL se configurada."""
    def __init__(self):
        s = get_settings(); self.s = s
        self.base_url = getattr(s, "ia_base_url", None) or None
    def generate(self, topic, platform):
        if not self.s.ia_api_key or self.s.ia_provider == "demo" or not self.base_url:
            return TextProvider().generate(topic, platform)
        prompt = f"Crie conteúdo factual, não enganoso, em pt-BR sobre {topic.title}. Plataforma: {platform}. Retorne título, gancho, roteiro, CTA, descrição, hashtags e palavras-chave."
        r = httpx.post(self.base_url, headers={"Authorization": f"Bearer {self.s.ia_api_key}"}, json={"model": self.s.ia_model, "prompt": prompt}, timeout=60)
        r.raise_for_status()
        data = r.json()
        return GeneratedContent(**data, demo=False)
