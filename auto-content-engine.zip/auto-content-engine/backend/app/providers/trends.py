import httpx
from app.core.config import get_settings

class YouTubeTrendSource:
    """Official YouTube Data API search source. It only activates with an API key."""
    def __init__(self, api_key: str): self.api_key = api_key
    def fetch(self, queries: list[str], max_results: int = 10):
        items=[]
        for q in queries:
            r=httpx.get('https://www.googleapis.com/youtube/v3/search', params={
                'part':'snippet','q':q,'type':'video','order':'viewCount','maxResults':max_results,'key':self.api_key
            }, timeout=30)
            r.raise_for_status()
            for item in r.json().get('items',[]):
                sn=item.get('snippet',{})
                items.append({'title':sn.get('title',''),'category':q,'keywords':q.split(','),'source':'YouTube Data API','external_id':item.get('id',{}).get('videoId')})
        return items

def configured_youtube_topics():
    s=get_settings()
    if not getattr(s,'youtube_api_key',None): return []
    queries=[x.strip() for x in getattr(s,'trend_queries','').split('|') if x.strip()]
    if not queries: queries=['indústria','automação industrial','inteligência artificial indústria','ferrovias','mineração','logística']
    return YouTubeTrendSource(s.youtube_api_key).fetch(queries)
