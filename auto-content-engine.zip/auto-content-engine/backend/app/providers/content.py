from abc import ABC, abstractmethod
from dataclasses import dataclass
from app.core.config import get_settings

@dataclass
class GeneratedContent:
    title: str
    hook: str
    script: str
    cta: str
    description: str
    hashtags: list[str]
    keywords: list[str]
    demo: bool = False

class ContentProvider(ABC):
    @abstractmethod
    def generate(self, topic, platform: str) -> GeneratedContent: ...

class TextProvider(ContentProvider):
    def generate(self, topic, platform):
        title = topic.title
        hook = f"Você sabia que {topic.title.lower()} pode mudar uma operação industrial?"
        script = (f"Hoje vamos entender {topic.title.lower()}. Primeiro, veja o problema. "
                  f"Depois, observe como tecnologia, processos e dados podem melhorar o resultado. "
                  f"O ponto principal é aplicar a solução com segurança, contexto e indicadores reais.")
        cta = "Se esse tema faz parte da sua rotina, salve e compartilhe para continuar a discussão."
        desc = f"Conteúdo educativo sobre {topic.category}: {topic.title}."
        tags = [f"#{x.replace(' ','')[:30]}" for x in topic.keywords[:8]] or ["#industria", "#logistica", "#tecnologia"]
        return GeneratedContent(title, hook, script, cta, desc, tags, topic.keywords, demo=True)

class ImageProvider:
    def generate(self, topic):
        return {"path": None, "demo": True, "message": "Imagem não gerada: provider externo não configurado."}

class VideoProvider:
    def generate(self, topic):
        return {"path": None, "demo": True, "message": "Vídeo não gerado: provider externo não configurado."}

def get_content_provider():
    settings = get_settings()
    # Arquitetura pronta para providers externos; texto demo é determinístico e não depende de API paga.
    return TextProvider()
