from abc import ABC, abstractmethod
import httpx

class TopicSource(ABC):
    @abstractmethod
    def fetch(self) -> list[dict]: ...

class DemoTopicSource(TopicSource):
    def __init__(self, items): self.items=items
    def fetch(self): return self.items

class JsonTopicSource(TopicSource):
    """Fonte configurável por URL que devolve uma lista JSON de objetos de tema.
    Não faz scraping: somente consome uma API/feed JSON explicitamente configurado."""
    def __init__(self, url): self.url=url
    def fetch(self):
        r=httpx.get(self.url,timeout=20); r.raise_for_status(); data=r.json()
        return data if isinstance(data,list) else data.get('items',[])
