from datetime import datetime, timezone
from sqlalchemy.orm import Session
from app.models import Post
from app.adapters.platforms import get_adapter

def publish_post(db: Session, post: Post, demo=True):
    post.status="PUBLISHING"; post.error_message=None; db.commit()
    try:
        result=get_adapter(post.platform, demo=demo).publish(post)
        post.status="PUBLISHED"; post.published_at=result["published_at"]; post.external_id=result["external_id"]
    except Exception as e:
        post.status="FAILED"; post.error_message=str(e)
    db.commit(); db.refresh(post); return post

def publish_due(db: Session, demo=True):
    now=datetime.now(timezone.utc)
    posts=db.query(Post).filter(Post.status=="SCHEDULED", Post.scheduled_at<=now).all()
    return [publish_post(db,p,demo) for p in posts]
