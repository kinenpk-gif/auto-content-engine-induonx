from datetime import datetime, timedelta, timezone
from sqlalchemy.orm import Session
from app.models import Topic, Post
from app.services.content_service import discover_topics
from app.services.content_service import create_post
from app.media.video_engine import VideoEngine
from app.core.config import load_yaml_config

PLATFORMS = ('youtube', 'tiktok', 'instagram')


def choose_duration(platform: str, monetization_goal: bool = True) -> int:
    # Strategy only; actual eligibility is platform/policy dependent and is validated separately.
    if monetization_goal and platform == 'tiktok':
        return 65
    if platform == 'youtube':
        return 55
    return 45


def run_autonomous_cycle(db: Session):
    cfg = load_yaml_config()
    topics = discover_topics(db)
    candidates = db.query(Topic).filter(Topic.status == 'NEW').order_by(Topic.score.desc()).limit(int(cfg.get('daily_quantity', 3))).all()
    engine = VideoEngine(cfg.get('media', {}).get('output_dir', 'generated'))
    created = []
    now = datetime.now(timezone.utc)
    platforms = [p for p in cfg.get('platforms', list(PLATFORMS)) if p in PLATFORMS]
    for topic in candidates:
        # One original master video is generated and can be adapted/cross-posted; this avoids needless duplicate rendering.
        master_platform = 'tiktok' if 'tiktok' in platforms else (platforms[0] if platforms else 'youtube')
        master = create_post(db, topic, master_platform, status='APPROVED')
        duration = choose_duration(master_platform, True)
        rendered = engine.render(master.title, master.script, duration, f'topic_{topic.id}_master.mp4')
        master.media_path = rendered['path']
        master.scheduled_at = now + timedelta(minutes=5 + len(created)*3)
        master.status = 'SCHEDULED'
        created.append(master.id)
        for platform in platforms:
            if platform == master_platform: continue
            post = create_post(db, topic, platform, status='APPROVED')
            post.media_path = rendered['path']
            post.scheduled_at = master.scheduled_at
            post.status = 'SCHEDULED'
            created.append(post.id)
        topic.status = 'APPROVED'
    db.commit()
    return {'topics_found': len(topics), 'posts_created': len(created), 'post_ids': created}
