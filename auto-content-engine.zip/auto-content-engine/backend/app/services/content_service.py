from sqlalchemy.orm import Session
from app.models import Topic, Post
from app.algorithms.scoring import topic_score
from app.providers.ai import ConfigurableLLMProvider
from app.core.config import load_yaml_config
from app.providers.topics import DemoTopicSource, JsonTopicSource
from app.providers.trends import configured_youtube_topics

DEFAULT_TOPICS = [
    ("Como a IA está transformando a manutenção industrial", "inteligência artificial", ["IA", "manutenção", "indústria 4.0"]),
    ("Por que a logística reversa é estratégica para a indústria", "logística", ["logística reversa", "supply chain", "sustentabilidade"]),
    ("Como funciona um pátio ferroviário moderno", "ferrovias", ["ferrovia", "pátio ferroviário", "logística"]),
    ("Automação industrial: sensores, dados e decisões", "automação industrial", ["automação", "sensores", "dados"]),
    ("O caminho de uma carga dentro de um porto", "portos", ["porto", "contêiner", "logística internacional"]),
    ("Onde a mineração usa inteligência artificial", "mineração", ["mineração", "IA", "segurança"]),
    ("Máquinas industriais que mudaram a produtividade", "máquinas", ["máquinas", "produtividade", "indústria"]),
]

def discover_topics(db: Session, source="DEMO"):
    created=[]
    cfg=load_yaml_config()
    source_defs=cfg.get("topic_sources") or [{"type":"demo","name":"Temas demonstrativos"}]
    items=[]
    # Prefer official live discovery when configured; DEMO remains the fallback and is explicitly labeled.
    try:
        items.extend(configured_youtube_topics())
    except Exception:
        pass
    for definition in source_defs:
        if definition.get("type")=="json" and definition.get("url"):
            try:
                items.extend(JsonTopicSource(definition["url"]).fetch())
            except Exception:
                # Uma fonte externa indisponível não é convertida em dado fictício.
                continue
        else:
            items.extend([{"title":t,"category":c,"keywords":k,"source":"DEMO"} for t,c,k in DEFAULT_TOPICS])
    for item in items:
        title=item.get("title")
        if not title: continue
        exists=db.query(Topic).filter(Topic.title==title).first()
        if exists: continue
        category=item.get("category","geral"); keywords=item.get("keywords",[])
        topic=Topic(title=title,category=category,keywords=keywords,source=item.get("source",source),
                    relevance=float(item.get("relevance",80)),interest_potential=float(item.get("interest_potential",75)),
                    novelty=float(item.get("novelty",70)),production_ease=float(item.get("production_ease",85)),
                    monetization_potential=float(item.get("monetization_potential",65)))
        topic.score=topic_score(topic.relevance,topic.interest_potential,topic.novelty,topic.production_ease,topic.monetization_potential)
        db.add(topic); created.append(topic)
    db.commit(); return created

def generate_script(db: Session, topic: Topic, platform: str):
    result = ConfigurableLLMProvider().generate(topic, platform)
    return result

def create_post(db: Session, topic: Topic, platform: str, scheduled_at=None, status="DRAFT"):
    c=generate_script(db, topic, platform)
    p=Post(topic_id=topic.id, platform=platform, title=c.title, caption=c.description+" "+" ".join(c.hashtags), script=c.script, scheduled_at=scheduled_at, status=status)
    db.add(p); db.commit(); db.refresh(p); return p
