from app.providers.topics import DemoTopicSource, JsonTopicSource
from app.services.content_service import DEFAULT_TOPICS

def configured_sources(cfg):
    sources=cfg.get('topic_sources') or [{'type':'demo'}]
    result=[]
    for source in sources:
        if source.get('type')=='json' and source.get('url'):
            result.append(JsonTopicSource(source['url']))
        else:
            result.append(DemoTopicSource([{'title':t,'category':c,'keywords':k} for t,c,k in DEFAULT_TOPICS]))
    return result
