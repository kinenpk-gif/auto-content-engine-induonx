from sqlalchemy.orm import Session
from sqlalchemy import func
from app.models import Post, ContentMetric, Revenue, Topic

def dashboard(db: Session):
    published=db.query(Post).filter(Post.status=="PUBLISHED").count()
    scheduled=db.query(Post).filter(Post.status=="SCHEDULED").count()
    failed=db.query(Post).filter(Post.status=="FAILED").count()
    views=int(db.query(func.coalesce(func.sum(ContentMetric.views),0)).scalar() or 0)
    engagement=float(db.query(func.coalesce(func.avg(ContentMetric.engagement_rate),0)).scalar() or 0)
    growth=int(db.query(func.coalesce(func.sum(ContentMetric.followers_gained),0)).scalar() or 0)
    revenue=float(db.query(func.coalesce(func.sum(Revenue.amount),0)).scalar() or 0)
    demo_rev=db.query(Revenue).filter(Revenue.is_demo==True).count() > 0
    best=[]
    for p,m in db.query(Post,ContentMetric).join(ContentMetric,ContentMetric.content_id==Post.id).order_by(ContentMetric.performance_score.desc()).limit(5):
        best.append({"id":p.id,"title":p.title,"platform":p.platform,"score":m.performance_score,"views":m.views})
    cats=[]
    for cat,score in db.query(Topic.category,func.avg(Topic.score)).group_by(Topic.category).order_by(func.avg(Topic.score).desc()).limit(8): cats.append({"category":cat,"score":round(float(score),2)})
    hours=[]
    for hour,count in db.query(func.extract('hour', Post.published_at),func.count(Post.id)).filter(Post.published_at!=None).group_by(func.strftime('%H',Post.published_at)).order_by(func.count(Post.id).desc()).limit(5): hours.append({"hour":hour,"count":count})
    queue=[]
    for p in db.query(Post).filter(Post.status.in_(["SCHEDULED","APPROVED","DRAFT"])).order_by(Post.scheduled_at).limit(10): queue.append({"id":p.id,"title":p.title,"platform":p.platform,"status":p.status,"scheduled_at":p.scheduled_at})
    return {"published":published,"scheduled":scheduled,"failed":failed,"views":views,"engagement":round(engagement,2),"growth":growth,"revenue":revenue,"revenue_is_demo":demo_rev,"best_contents":best,"best_categories":cats,"best_hours":hours,"queue":queue}
