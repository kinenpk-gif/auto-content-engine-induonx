from sqlalchemy.orm import Session
from sqlalchemy import func
from app.models import ContentMetric, Post, Topic
from app.algorithms.scoring import performance_score, learning_priority

def record_metric(db: Session, data):
    m=ContentMetric(**data.model_dump())
    m.engagement_rate = ((m.likes + m.comments + m.shares) / m.views * 100) if m.views else 0
    m.performance_score = performance_score(m.views,m.likes,m.comments,m.shares,m.followers_gained,m.ctr)
    db.add(m); db.commit(); db.refresh(m); return m

def learn(db: Session):
    rows=db.query(Topic.id, Topic.category, func.avg(ContentMetric.performance_score)).join(Post, Post.topic_id==Topic.id).join(ContentMetric, ContentMetric.content_id==Post.id).group_by(Topic.id, Topic.category).all()
    category={}
    for _, cat, score in rows: category.setdefault(cat, []).append(float(score or 0))
    for t in db.query(Topic).all():
        cat_score=sum(category.get(t.category,[0]))/len(category.get(t.category,[1]))
        t.score=learning_priority(t.score, cat_score, cat_score)
    db.commit()
