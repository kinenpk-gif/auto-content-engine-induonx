from datetime import datetime, timedelta, timezone
from app.models import Topic, Post, ContentMetric, Revenue
from app.services.content_service import discover_topics, create_post

def seed(db):
    topics=discover_topics(db)
    topics=db.query(Topic).order_by(Topic.score.desc()).limit(6).all()
    platforms=["youtube","instagram","tiktok"]
    created=0
    for i,t in enumerate(topics):
        for j,pl in enumerate(platforms):
            if db.query(Post).filter(Post.topic_id==t.id,Post.platform==pl).first(): continue
            p=create_post(db,t,pl,status="PUBLISHED")
            p.published_at=datetime.now(timezone.utc)-timedelta(days=i, hours=j)
            p.external_id=f"demo-{pl}-{p.id}"
            db.commit()
            m=ContentMetric(content_id=p.id,views=1500+i*900+j*300,likes=100+i*40,comments=12+i*5,shares=22+i*4,followers_gained=10+i*3,ctr=0.025+i*0.004)
            m.engagement_rate=(m.likes+m.comments+m.shares)/m.views*100
            m.performance_score=min(100,20+i*10+j*3)
            db.add(m)
            db.add(Revenue(platform=pl,source="DEMO",content_id=p.id,amount=5+i*2,currency="BRL",is_demo=True))
            db.commit(); created+=1
    return {"status":"ok","demo":True,"topics":len(topics),"posts_created":created,"message":"Dados demonstrativos — não representam receita real."}
