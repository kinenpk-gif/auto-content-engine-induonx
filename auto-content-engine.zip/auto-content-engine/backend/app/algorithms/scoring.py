def topic_score(relevance, interest_potential, novelty, production_ease, monetization_potential):
    values = [max(0, min(100, float(v))) for v in (relevance, interest_potential, novelty, production_ease, monetization_potential)]
    weights = [0.25, 0.25, 0.20, 0.10, 0.20]
    return round(sum(v*w for v, w in zip(values, weights)), 2)

def performance_score(views, likes, comments, shares, followers_gained, ctr=None):
    if views <= 0: return 0.0
    engagement = (likes + 2*comments + 3*shares) / views * 100
    reach_component = min(100, views / 1000)
    follower_component = min(100, followers_gained / max(1, views) * 1000)
    ctr_component = min(100, (ctr or 0) * 100)
    return round(min(100, 0.35*engagement*10 + 0.30*reach_component + 0.20*follower_component + 0.15*ctr_component), 2)

def learning_priority(base_score, category_performance, similar_topic_performance):
    boost = 0.5 * category_performance + 0.5 * similar_topic_performance
    return round(min(100, 0.6*base_score + 0.4*boost), 2)
