from app.core.config import load_yaml_config, get_settings
from app.database.session import SessionLocal
from app.services.content_service import discover_topics, create_post
from app.services.publishing_service import publish_due
from app.services.autonomous_service import run_autonomous_cycle

try:
    from apscheduler.schedulers.background import BackgroundScheduler
    from apscheduler.triggers.cron import CronTrigger
except ImportError:  # permite modo DEMO/teste mesmo antes de instalar dependências opcionais
    BackgroundScheduler = None
    CronTrigger = None

scheduler = BackgroundScheduler(timezone="America/Sao_Paulo") if BackgroundScheduler else None

def job_research():
    db=SessionLocal()
    try: discover_topics(db)
    finally: db.close()

def job_scripts():
    db=SessionLocal()
    try:
        from app.models import Topic
        cfg=load_yaml_config()
        topics=db.query(Topic).filter_by(status="NEW").order_by(Topic.score.desc()).limit(int(cfg.get("daily_quantity",3))).all()
        for t in topics:
            for platform in cfg.get("platforms",["text"]):
                create_post(db,t,platform,status="APPROVED")
            t.status="APPROVED"
        db.commit()
    finally: db.close()

def job_content():
    # A geração textual já ocorre no create_post; providers de mídia podem ser adicionados aqui.
    return job_scripts()

def job_autonomous():
    db=SessionLocal()
    try: return run_autonomous_cycle(db)
    finally: db.close()

def job_publish():
    db=SessionLocal()
    try: publish_due(db, demo=load_yaml_config().get("demo_mode",True))
    finally: db.close()

def start_scheduler():
    if not get_settings().scheduler_enabled or scheduler is None or scheduler.running: return
    cfg=load_yaml_config().get("schedules",{})
    mapping={"research":job_research,"scripts":job_scripts,"content":job_content,"queue":job_publish,"autonomous":job_autonomous}
    for name,fn in mapping.items():
        if name not in cfg: continue
        hh,mm=cfg[name].split(":")
        scheduler.add_job(fn,CronTrigger(hour=int(hh),minute=int(mm)),id=name,replace_existing=True)
    scheduler.start()
