from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field
from typing import Any

class TopicCreate(BaseModel):
    title: str
    category: str
    keywords: list[str] = []
    source: str = "DEMO"
    relevance: float = 50
    interest_potential: float = 50
    novelty: float = 50
    production_ease: float = 50
    monetization_potential: float = 50

class TopicOut(TopicCreate):
    id: int
    score: float
    status: str
    discovered_at: datetime
    model_config = ConfigDict(from_attributes=True)

class ScriptOut(BaseModel):
    title: str
    hook: str
    script: str
    cta: str
    description: str
    hashtags: list[str]
    keywords: list[str]
    platform: str
    demo: bool = False

class PostCreate(BaseModel):
    topic_id: int | None = None
    platform: str
    title: str
    caption: str = ""
    script: str = ""
    media_path: str | None = None
    scheduled_at: datetime | None = None
    status: str = "DRAFT"

class PostOut(PostCreate):
    id: int
    published_at: datetime | None = None
    external_id: str | None = None
    error_message: str | None = None
    model_config = ConfigDict(from_attributes=True)

class MetricCreate(BaseModel):
    content_id: int
    views: int = 0
    likes: int = 0
    comments: int = 0
    shares: int = 0
    followers_gained: int = 0
    ctr: float | None = None

class RevenueCreate(BaseModel):
    platform: str
    source: str
    content_id: int | None = None
    amount: float
    currency: str = "BRL"
    is_demo: bool = False

class Dashboard(BaseModel):
    published: int
    scheduled: int
    failed: int
    views: int
    engagement: float
    growth: int
    revenue: float
    revenue_is_demo: bool
    best_contents: list[dict[str, Any]]
    best_categories: list[dict[str, Any]]
    best_hours: list[dict[str, Any]]
    queue: list[dict[str, Any]]
