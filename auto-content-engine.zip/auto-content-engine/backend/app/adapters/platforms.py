from abc import ABC, abstractmethod
from datetime import datetime, timezone
import httpx
from app.core.config import get_settings

class PlatformAdapter(ABC):
    platform = "unknown"
    @abstractmethod
    def publish(self, post): ...
    def metrics(self, external_id): return None

class MockPlatformAdapter(PlatformAdapter):
    def __init__(self, platform): self.platform = platform
    def publish(self, post):
        return {"external_id": f"demo-{self.platform}-{post.id}", "published_at": datetime.now(timezone.utc), "demo": True}
    def metrics(self, external_id):
        return {"views": 1200, "likes": 84, "comments": 12, "shares": 19, "followers_gained": 8, "ctr": 0.031, "demo": True}

class YouTubeAdapter(PlatformAdapter):
    platform = "youtube"
    def publish(self, post):
        s = get_settings()
        if not s.youtube_access_token:
            raise RuntimeError("YouTube API não configurada: YOUTUBE_ACCESS_TOKEN ausente.")
        if not post.media_path:
            raise RuntimeError("Post sem media_path.")
        try:
            from google.oauth2.credentials import Credentials
            from googleapiclient.discovery import build
            from googleapiclient.http import MediaFileUpload
        except ImportError as e:
            raise RuntimeError("Dependências Google não instaladas; execute pip install -r backend/requirements.txt") from e
        creds = Credentials(token=s.youtube_access_token, scopes=["https://www.googleapis.com/auth/youtube.upload"])
        youtube = build("youtube", "v3", credentials=creds)
        body = {"snippet": {"title": post.title[:100], "description": post.caption, "categoryId": "28"},
                "status": {"privacyStatus": "public", "selfDeclaredMadeForKids": False}}
        req = youtube.videos().insert(part="snippet,status", body=body, media_body=MediaFileUpload(post.media_path, mimetype="video/mp4", resumable=True))
        response = req.execute()
        return {"external_id": response["id"], "published_at": datetime.now(timezone.utc), "demo": False}

class InstagramAdapter(PlatformAdapter):
    platform = "instagram"
    def publish(self, post):
        s = get_settings()
        if not s.instagram_access_token or not s.instagram_business_account_id:
            raise RuntimeError("Instagram Graph API não configurada: token/Business Account ID ausentes.")
        raise RuntimeError("Instagram Publishing API exige container de mídia e permissões Meta configuradas; use DEMO até concluir OAuth.")

class TikTokAdapter(PlatformAdapter):
    platform = "tiktok"
    def publish(self, post):
        s = get_settings()
        if not s.tiktok_access_token: raise RuntimeError("TikTok Content Posting API não configurada: TIKTOK_ACCESS_TOKEN ausente.")
        raise RuntimeError("TikTok Content Posting API exige app aprovado, OAuth e fluxo de upload configurado; use DEMO até concluir OAuth.")

def get_adapter(platform, demo=False):
    if demo: return MockPlatformAdapter(platform)
    return {"youtube": YouTubeAdapter(), "instagram": InstagramAdapter(), "tiktok": TikTokAdapter()}.get(platform, MockPlatformAdapter(platform))
