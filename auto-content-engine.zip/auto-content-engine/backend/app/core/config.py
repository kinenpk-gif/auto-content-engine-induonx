from functools import lru_cache
from pathlib import Path
import os, yaml
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parents[3]

class Settings(BaseSettings):
    app_name: str = "AutoContent Engine"
    environment: str = "demo"
    database_url: str = "sqlite:///./auto_content.db"
    ia_provider: str = "demo"
    ia_api_key: str | None = None
    ia_model: str = ""
    ia_base_url: str | None = None
    youtube_access_token: str | None = None
    youtube_api_key: str | None = None
    trend_queries: str = "indústria|automação industrial|inteligência artificial indústria|ferrovias|mineração|logística"
    instagram_access_token: str | None = None
    instagram_business_account_id: str | None = None
    tiktok_access_token: str | None = None
    scheduler_enabled: bool = True
    cors_origins: str = "http://localhost:5173"
    config_path: str = str(ROOT / "config.yaml")
    model_config = SettingsConfigDict(env_file=str(ROOT / ".env"), extra="ignore")

    @property
    def cors_list(self):
        return [x.strip() for x in self.cors_origins.split(",") if x.strip()]

@lru_cache
def get_settings():
    return Settings()

def load_yaml_config(path: str | None = None):
    p = Path(path or get_settings().config_path)
    if not p.exists():
        return {}
    with p.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}
