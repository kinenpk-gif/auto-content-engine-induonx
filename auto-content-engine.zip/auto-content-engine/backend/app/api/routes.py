from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.models import Topic, Post, Revenue
from app.schemas import TopicCreate, TopicOut, PostCreate, PostOut, MetricCreate, RevenueCreate, ScriptOut
from app.services.content_service import discover_topics, create_post, generate_script
from app.services.analytics_service import record_metric, learn
from app.services.dashboard_service import dashboard
from app.services.publishing_service import publish_post
from app.core.config import load_yaml_config
from app.services.autonomous_service import run_autonomous_cycle

router=APIRouter()
@router.get('/health')
def health(): return {'status':'ok','service':'auto-content-engine'}
@router.get('/dashboard')
def get_dashboard(db:Session=Depends(get_db)): return dashboard(db)
@router.post('/topics/discover')
def discover(db:Session=Depends(get_db)): return [x for x in discover_topics(db)]
@router.get('/topics',response_model=list[TopicOut])
def topics(db:Session=Depends(get_db)): return db.query(Topic).order_by(Topic.score.desc()).all()
@router.post('/topics',response_model=TopicOut)
def add_topic(data:TopicCreate,db:Session=Depends(get_db)):
    from app.algorithms.scoring import topic_score
    t=Topic(**data.model_dump()); t.score=topic_score(t.relevance,t.interest_potential,t.novelty,t.production_ease,t.monetization_potential); db.add(t); db.commit(); db.refresh(t); return t
@router.post('/topics/{topic_id}/script',response_model=ScriptOut)
def script(topic_id:int,platform:str='youtube',db:Session=Depends(get_db)):
    t=db.get(Topic,topic_id)
    if not t: raise HTTPException(404,'Tema não encontrado')
    c=generate_script(db,t,platform); return {**c.__dict__, 'platform':platform}
@router.get('/posts',response_model=list[PostOut])
def posts(db:Session=Depends(get_db)): return db.query(Post).order_by(Post.created_at.desc()).all()
@router.post('/posts',response_model=PostOut)
def add_post(data:PostCreate,db:Session=Depends(get_db)):
    p=Post(**data.model_dump()); db.add(p); db.commit(); db.refresh(p); return p
@router.post('/topics/{topic_id}/posts',response_model=PostOut)
def generate_post(topic_id:int,platform:str='youtube',db:Session=Depends(get_db)):
    t=db.get(Topic,topic_id)
    if not t: raise HTTPException(404,'Tema não encontrado')
    return create_post(db,t,platform,status='APPROVED')
@router.post('/posts/{post_id}/publish',response_model=PostOut)
def publish(post_id:int,db:Session=Depends(get_db)):
    p=db.get(Post,post_id)
    if not p: raise HTTPException(404,'Post não encontrado')
    demo=load_yaml_config().get('demo_mode',True)
    return publish_post(db,p,demo=demo)
@router.post('/metrics')
def metrics(data:MetricCreate,db:Session=Depends(get_db)): return record_metric(db,data)
@router.post('/learning')
def learning(db:Session=Depends(get_db)): learn(db); return {'status':'updated'}
@router.post('/revenue')
def revenue(data:RevenueCreate,db:Session=Depends(get_db)):
    r=Revenue(**data.model_dump()); db.add(r); db.commit(); db.refresh(r); return r
@router.post('/autonomous/run')
def autonomous_run(db:Session=Depends(get_db)): return run_autonomous_cycle(db)

@router.post('/demo/seed')
def seed_demo(db:Session=Depends(get_db)):
    from app.services.demo_seed import seed
    return seed(db)
