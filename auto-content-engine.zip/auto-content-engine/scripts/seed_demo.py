import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
from app.database.session import SessionLocal, init_db
from app.services.demo_seed import seed

if __name__ == "__main__":
    init_db()
    print(seed(SessionLocal()))
