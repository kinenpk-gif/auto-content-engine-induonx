export type Dashboard={published:number;scheduled:number;failed:number;views:number;engagement:number;growth:number;revenue:number;revenue_is_demo:boolean;best_contents:any[];best_categories:any[];best_hours:any[];queue:any[]};
export type Topic={id:number;title:string;category:string;score:number;status:string;source:string;keywords:string[]};
