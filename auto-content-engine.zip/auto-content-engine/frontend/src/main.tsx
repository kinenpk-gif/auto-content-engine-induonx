import React from 'react';import{createRoot}from'react-dom/client';import'./index.css';import Dashboard from'./pages/Dashboard';
createRoot(document.getElementById('root')!).render(<React.StrictMode><main className="min-h-screen p-6 md:p-10"><Dashboard/></main></React.StrictMode>);
