const API=import.meta.env.VITE_API_URL||'http://localhost:8000/api';
export async function getDashboard(){return fetch(`${API}/dashboard`).then(r=>r.json())}
export async function getTopics(){return fetch(`${API}/topics`).then(r=>r.json())}
export async function discover(){return fetch(`${API}/topics/discover`,{method:'POST'}).then(r=>r.json())}
export async function seedDemo(){return fetch(`${API}/demo/seed`,{method:'POST'}).then(r=>r.json())}
